package com.example.myapplication2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;


import android.content.Intent;


import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CustomerRegisterActivity extends AppCompatActivity {
    private EditText mNameField, mPhoneField;
    private ImageButton   mRegistration;
    private ImageView midImage;
    private EditText mEmail, mPassword;
    private DatabaseReference current_user_db;
    private String userID;
    private String mName;
    private String mPhone;
    private String mProfileImageUrl;
    private Uri resultUri;
    private Uri resultUri2;

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_register);

        mAuth = FirebaseAuth.getInstance();





        mNameField= (EditText) findViewById(R.id.name);
        mPhoneField= (EditText) findViewById(R.id.phone);

        midImage = (ImageView) findViewById(R.id.profile_image);


        mEmail= (EditText) findViewById(R.id.emailo);
        mPassword= (EditText) findViewById(R.id.passwordo);
        mRegistration= (ImageButton) findViewById(R.id.registrationt);


        //userID = mAuth.getCurrentUser().getUid();
        //mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(userID);


        firebaseAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                //userID = mAuth.getCurrentUser().getUid();

                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if(user!=null){

                    Intent intent = new Intent(CustomerRegisterActivity.this, Main2Activity.class);
                    startActivity(intent);
                    finish();
                    return;
                }
            }
        };




        midImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, 1);
            }
        });

        mRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //saveUserInformation();

                /*final String email = mEmail.getText().toString();
                final String password = mPassword.getText().toString();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(CustomerRegisterActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()){
                            Toast.makeText(CustomerRegisterActivity.this, "sign in error", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                Toast.makeText(CustomerRegisterActivity.this, "You Have Sucessfully Registered", Toast.LENGTH_SHORT).show();*/

                final String email = mEmail.getText().toString();
                final String password = mPassword.getText().toString();
                mName = mNameField.getText().toString();
                mPhone = mPhoneField.getText().toString();
                if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password) && !TextUtils.isEmpty(mName) && !TextUtils.isEmpty(mPhone)   ) {
                    if (mEmail != null && mPassword != null && mName != null && mPhone != null && midImage != null) {
                        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(CustomerRegisterActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (!task.isSuccessful()) {
                                    Toast.makeText(CustomerRegisterActivity.this, "sign up error", Toast.LENGTH_SHORT).show();
                                } else {
                                    userID = mAuth.getCurrentUser().getUid();
                                    current_user_db = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(userID);
                                    current_user_db.setValue(true);
                                    //mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(userID);
                                    Toast.makeText(CustomerRegisterActivity.this, "You Have Successfuly Registered", Toast.LENGTH_SHORT).show();
                                    saveUserInformation();
                                }
                            }
                        });
                    }
                }
                else
                    Toast.makeText(CustomerRegisterActivity.this, "Enter required information", Toast.LENGTH_SHORT).show();

            }
        });


    }


    private void saveUserInformation() {




        mName = mNameField.getText().toString();
        mPhone = mPhoneField.getText().toString();

        Map userInfo = new HashMap();
        userInfo.put("name", mName);
        userInfo.put("phone", mPhone);
        current_user_db.updateChildren(userInfo);

        if(resultUri != null){
            StorageReference filePath = FirebaseStorage.getInstance().getReference().child("propic").child(userID);
            Bitmap bitmap = null;

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getApplication().getContentResolver(), resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos);
            byte[] data = baos.toByteArray();
            UploadTask uploadTask = filePath.putBytes(data);

            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    finish();
                    return;
                }
            });
            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Task<Uri> uri = taskSnapshot.getStorage().getDownloadUrl();
                    while (!uri.isComplete());
                    Uri downloadUrl = uri.getResult();

                    Map newImage = new HashMap();
                    newImage.put("profileImageUrl", downloadUrl.toString());
                    current_user_db.updateChildren(newImage);

                    finish();
                    return;
                }
            });
        }


        else{
            finish();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            final Uri imageUri = data.getData();
            resultUri = imageUri;
            midImage.setImageURI(resultUri);
        }
        if(requestCode == 2 && resultCode == Activity.RESULT_OK) {
            final Uri imageUri = data.getData();
            resultUri2 = imageUri;
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(firebaseAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAuth.removeAuthStateListener(firebaseAuthListener);
    }



}