package com.example.myapplication2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;



public class RecycleActivity extends AppCompatActivity {

    public String number;
    private static final int REQUEST_CALL = 1;
    private ImageButton b1;
    private ImageButton b2;
    private ImageButton b3;
    private ImageButton b4;
    private ImageButton b5;
    private ImageButton b6;
    private ImageButton b7;
    private ImageButton b8;
    private ImageButton b9;
    private ImageButton b10;
    private ImageButton b11;
    private ImageButton b12;
    private ImageButton b13;
    private ImageButton b14;
    private ImageButton b15;
    private ImageButton b16;
    private ImageButton b17;
    private ImageButton b18;
    private ImageButton b19;
    private ImageButton b20;
    private ImageButton b21;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_municipal);

        //ImageButton b1 = findViewById(R.id.b1);
        b1= (ImageButton) findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "8666670640";
                makePhoneCall();

            }
        });

        b2= (ImageButton) findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "180030102866";
                makePhoneCall();

            }
        });

        b3= (ImageButton) findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "6122321858";
                makePhoneCall();

            }
        });

        b4= (ImageButton) findViewById(R.id.b4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "8037301764";
                makePhoneCall();

            }
        });

        b5= (ImageButton) findViewById(R.id.b5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "085509 85777";
                makePhoneCall();

            }
        });

        b6= (ImageButton) findViewById(R.id.b6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "8048110241";
                makePhoneCall();

            }
        });

        b7= (ImageButton) findViewById(R.id.b7);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "9899310325";
                makePhoneCall();

            }
        });

        b8= (ImageButton) findViewById(R.id.b8);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "180030102866";
                makePhoneCall();

            }
        });

        b9= (ImageButton) findViewById(R.id.b9);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "7823925596";
                makePhoneCall();

            }
        });

        b10= (ImageButton) findViewById(R.id.b10);
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "8089750432";
                makePhoneCall();

            }
        });

        b11= (ImageButton) findViewById(R.id.b11);
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "7480400400\n";
                makePhoneCall();

            }
        });

        b12= (ImageButton) findViewById(R.id.b12);
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "7666562225";
                makePhoneCall();

            }
        });

        b13= (ImageButton) findViewById(R.id.b13);
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "9612201016";
                makePhoneCall();

            }
        });

        b14= (ImageButton) findViewById(R.id.b14);
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "674 255 2408";
                makePhoneCall();

            }
        });

        b15= (ImageButton) findViewById(R.id.b15);
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "94370 02723";
                makePhoneCall();

            }
        });

        b16= (ImageButton) findViewById(R.id.b16);
        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "98725 31910";
                makePhoneCall();

            }
        });

        b17= (ImageButton) findViewById(R.id.b17);
        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "124 437 5804";
                makePhoneCall();

            }
        });

        b18= (ImageButton) findViewById(R.id.b18);
        b18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "99408 31313";
                makePhoneCall();

            }
        });

        b19= (ImageButton) findViewById(R.id.b19);
        b19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "9000793504";
                makePhoneCall();

            }
        });

        b20= (ImageButton) findViewById(R.id.b20);
        b20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 267 6000";
                makePhoneCall();

            }
        });

        b21= (ImageButton) findViewById(R.id.b21);
        b21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "97480 5050";
                makePhoneCall();

            }
        });

    }

    private void makePhoneCall() {


        if (number.trim().length() > 0) {
            if (ContextCompat.checkSelfPermission(RecycleActivity.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(RecycleActivity.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }
        }

    }

    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
                                             @NonNull int[] grantResults){
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
