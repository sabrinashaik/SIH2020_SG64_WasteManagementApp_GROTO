package com.example.myapplication2;

import android.os.Bundle;
import android.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.*;



import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.nio.DoubleBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class WasteActivity extends AppCompatActivity {

    private Switch mSolSwitch, mGasSwitch, mLiqSwitch;
    private TextView mSolid, mLiquid, mGas;
    private EditText mSolText, mLiqText, mGasText, mSolq, mLiqq, mGasq;
    private ImageButton mConfirm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waste);

        mSolSwitch = (Switch) findViewById(R.id.solswitch);
        mGasSwitch = (Switch) findViewById(R.id.gasswitch);
        mLiqSwitch = (Switch) findViewById(R.id.liqswitch);

        mSolid = (TextView) findViewById(R.id.soltextView);
        mLiquid = (TextView) findViewById(R.id.liqtextView);
        mGas = (TextView) findViewById(R.id.gastextView);

        mSolText = (EditText) findViewById(R.id.soleditText);
        mLiqText = (EditText) findViewById(R.id.liqeditText);
        mGasText = (EditText) findViewById(R.id.gaseditText);

        mSolq = (EditText) findViewById(R.id.solquaneditText);
        mLiqq = (EditText) findViewById(R.id.liqquaneditText);
        mGasq = (EditText) findViewById(R.id.gasquaneditText);

        mConfirm= (ImageButton) findViewById(R.id.confirmbutton);

        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    Toast.makeText(WasteActivity.this, "Thank you for entering waste details", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
            }
        });



    }

}
