from flask import Flask, render_template, request, url_for
import string,csv
from collections import Counter
import matplotlib.pyplot as plt
import pickle
import os


app = Flask(__name__, template_folder='template')




@app.route('/',methods=['GET','POST'])
def form():

	return render_template('index.html')

@app.route('/2016',methods=['GET','POST'])
def graph(form):
	if request.method == 'POST':
		if request.form['submit'] == '2016':
           
		
			return render_template('2016.html',form=form)
	
		
if __name__ == "__main__":
    app.run(debug=True)