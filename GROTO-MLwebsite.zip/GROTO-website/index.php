<!DOCTYPE html>
<html>
<head>
 <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<head>
    <nav class="navbar navbar-light bg-light">
        <h1 class="navbar-brand"><div style="color:#900000 "><b>G.R.O.T.O-Green Route to our Future</b></h1></div>
    </nav>

</head>


<body>

<div class="row row-cols-1 row-cols-md-2">
  <div class="col mb-4">
    <div class="card text-white bg-info mb-3">
      <class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Waste Generation Vs Waste Processing</h5>
        <p class="card-text">A bargraph representing  India's State wise Waste generation Vs Waste processing quantities per year in Metric Tons</p>
 <a href="GenerationVs Processing.php" class="btn btn-dark">Click To View!</a>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card text-white bg-info mb-3">
      <class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Per Day Waste Generation</h5>
        <p class="card-text">A bargraph & Pie chart representing  India's State wise Waste generation quantities  in Metric Tons per day</p>
 <a href="PerDayWasteGen.php" class="btn btn-dark">Click To View!</a>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card text-white bg-info mb-3">
      <class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Manufacturing Industries waste generation </h5>
        <p class="card-text">A bargraph plotting Categories of various manufacturing industries & their percentage of waste generation during manufacturing.  </p>
 <a href="ManufacturingIndustries.php" class="btn btn-dark">Click To View!</a>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card text-white bg-info mb-3">
      <class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Future years Waste predection through Regression</h5>
        <p class="card-text">Bargraphs predicting and plotting the comming years state wise Waste Generation quantities in Metric Tons </p>
       <a href="Futurepredection.php" class="btn btn-dark">Click To View!</a>
      </div>
    </div>
  </div>
</div>




 <script 
src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>

</html>