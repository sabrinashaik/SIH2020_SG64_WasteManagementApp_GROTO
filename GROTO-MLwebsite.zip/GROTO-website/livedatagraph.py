import random
from itertools import count
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


df=pd.read_csv("livedataset.csv")
x=df.iloc[:,:-1]
y = df.iloc[:,-1]
#to work with onehotencoder we need one extra class know as colimntranformer 
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
ct= ColumnTransformer([('encoder'),OneHotEncoder(),[0]])
states = pd.get_dummies(df.States, prefix='States')
df.drop('States',axis=1,inplace = True)
df=pd.concat([df,states],axis=1)
x=df.iloc[:,:].values
from sklearn.model_selection import train_test_split
x_train , x_test, y_train, y_test = train_test_split(x,y,train_size = 0.8, random_state =8)
from sklearn.svm import SVC
from sklearn import svm

classifier= svm.SVC(C=1, kernel='linear', random_state=0)
classifier.fit(x_train,y_train)
y_pred = classifier.predict(x_test)
from mlxtend.plotting import plot_decision_regions
from sklearn.decomposition import PCA



plt.style.use('fivethirtyeight')

x_vals = []
y_vals = []

index = count()


def animate(i):
    data = pd.read_csv('data.csv')
    x = data['x_value']
    y1 = data['total_1']
    y2 = data['total_2']

    plt.cla()

    plt.plot(x, y1, label='North India')
    plt.plot(x, y2, label='South India')
    

    plt.legend(loc='upper left')
    plt.tight_layout()


ani = FuncAnimation(plt.gcf(), animate, interval=1000)

plt.tight_layout()
plt.show()