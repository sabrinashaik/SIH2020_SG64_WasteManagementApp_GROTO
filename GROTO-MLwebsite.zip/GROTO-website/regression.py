import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('StateUT.csv')

x=df.iloc[:-1,1:5].values
y = df.iloc[:-1,4].values #2018
y1=df.iloc[:-1,3].values #2017
y2=df.iloc[:-1,2].values #2016
#print(x)

print('States/UTs')
print(df['States'].value_counts())

# since our ML models cannot work with categorical data we need to encode them i.e. convert them into numeric format
# for encoding here we are going to use two encoders Onehotencoder and labelEncoder
# to work with onehotencoder we need one extra class known as columntranformer
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
ct = ColumnTransformer(transformers=[('encoder',OneHotEncoder(),[0])],remainder='passthrough')
# fit and transform my data
#x = np.array(ct.fit_transform(x))
#print(x)

states = pd.get_dummies(df.States, prefix='States')
#print(states.head())

#x=x.drop('State',axis=1)
df.drop('States',axis=1,inplace = True)
df=pd.concat([df,states],axis=1)

df.drop('Total waste processing (in percentage) - Dec-2016',axis=1,inplace = True)
df.drop('Total waste processing (in percentage) - Dec-2017',axis=1,inplace = True)
df.drop('Total waste processing (in percentage) - Dec-2018',axis=1,inplace = True)

x=df.iloc[:-1,:].values

from sklearn.model_selection import train_test_split
x_train , x_test, y_train, y_test = train_test_split(x,y,test_size = 0.25, random_state =8)

print(x_train)
print(x_test)
print(y_train)
print(y_test)

from sklearn.linear_model import LinearRegression
# LinearRegression class which we are using here automatically takes care of the dummy variable trap
reg = LinearRegression()
reg.fit(x_train,y_train)

y_pred = reg.predict(x)
#print(y_pred)

from sklearn.model_selection import train_test_split
x_train , x_test, y_train1, y_test1 = train_test_split(x,y1,test_size = 0.25, random_state =8)

from sklearn.linear_model import LinearRegression
# LinearRegression class which we are using here automatically takes care of the dummy variable trap
reg = LinearRegression()
reg.fit(x_train,y_train1)

y_pred1 = reg.predict(x)
#print(y_pred1)

from sklearn.model_selection import train_test_split
x_train , x_test, y_train2, y_test2 = train_test_split(x,y2,test_size = 0.25, random_state =8)

from sklearn.linear_model import LinearRegression
# LinearRegression class which we are using here automatically takes care of the dummy variable trap
reg = LinearRegression()
reg.fit(x_train,y_train2)

y_pred2 = reg.predict(x)
#print(y_pred2)

import statistics 
result2019=(y_pred+y_pred1+y_pred2)/3
print(result2019)

import statistics 
result2020=(y_pred+y_pred1+y_pred2+result2019)/4
print(result2020)

import statistics 
result2021=(y_pred+y_pred1+y_pred2+result2020)/5
print(result2021)

import statistics 
result2023=(y_pred+y_pred1+y_pred2+result2022)/3
print(result2023)

import sklearn.metrics as met

r2_score = met.r2_score(y,y_pred)
print(r2_score)

