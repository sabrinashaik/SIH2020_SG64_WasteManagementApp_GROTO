import csv
import numpy as np
import pandas as pd
from collections import Counter
from matplotlib import pyplot as plt
data = pd.read_csv('StateUT-wise Status of Solid Waste Generated and Processed from 2016 to 2018.csv')
states = data['States/UTs'].values
x = np.arange(len(states))
wgen2016 = data['Total waste generation (Metric Tonnes Per Day) - Dec-2016']
wgen2017 = data['Total waste generation (Metric Tonnes Per Day) - Dec-2017']
wgen2018 = data['Total waste generation (Metric Tonnes Per Day) - Dec-2018']
wpro2016=data['Total waste processing (in percentage) - Dec-2016']
wpro2017=data['Total waste processing (in percentage) - Dec-2017']
wpro2018=data['Total waste processing (in percentage) - Dec-2018']
dataFrame=pd.DataFrame(states,wgen2018)
data.plot.area(stacked=False,alpha = 0.3,figsize=(8,8))
plt.ylim([0,19000])
#dataFrame.plot.area(stacked=False,alpha = 0.6,figsize=(8,13)) 
#plt.savefig('areagraph.png')
w = 0.6
plt.figure(figsize=(18,7))
plt.bar(x-w, data['Total waste generation (Metric Tonnes Per Day) - Dec-2016'].values, width=w, label='Waste Generated-2016')
plt.bar(x, data['Total waste processing (in percentage) - Dec-2016'].values, width=w, label='Waste Processed-2016')
plt.xticks(x, states,rotation=70,horizontalalignment='right')
plt.ylim([0,1900])
plt.tight_layout()
plt.title("Waste Generation Vs Waste Processing of 2016",fontsize='20')
plt.xlabel('States',fontsize='16')
plt.legend(loc='upper center', bbox_to_anchor=(0.8, -0.5))#, fancybox=True, ncol=5)
#plt.savefig('graph2016.png')
w = 0.6
plt.figure(figsize=(18,5))
plt.bar(x-w, data['Total waste generation (Metric Tonnes Per Day) - Dec-2017'].values, width=w, label='Waste Generated-2017')
plt.bar(x, data['Total waste processing (in percentage) - Dec-2017'].values, width=w, label='Waste Processed-2017')
plt.xticks(x, states,rotation=70,horizontalalignment='right')
plt.ylim([0,1900])
#plt.tight_layout()
plt.title("Waste Generation Vs Waste Processing of 2017",fontsize='20')
plt.xlabel('States',fontsize='16')
plt.legend(loc='upper center', bbox_to_anchor=(0.8, -0.5))#, fancybox=True, ncol=5)
#plt.savefig('graph2017.png')
w = 0.6
plt.figure(figsize=(18,5))
plt.bar(x-w, data['Total waste generation (Metric Tonnes Per Day) - Dec-2018'].values, width=w, label='Waste Generated-2018')
plt.bar(x, data['Total waste processing (in percentage) - Dec-2018'].values, width=w, label='Waste Processed-2018')

plt.xticks(x, states,rotation=70,horizontalalignment='right')
plt.ylim([0,1900])
#plt.tight_layout()
plt.title("Waste Generation Vs Waste Processing of 2018",fontsize='20')
plt.xlabel('States',fontsize='16')
plt.legend(loc='upper center', bbox_to_anchor=(0.8, -0.5),ncol=5)#, fancybox=True, ncol=5)
#plt.savefig('2018graph.png')
data = pd.read_csv('Statewiseperdaywaste2.csv')
states = data['State'].values
x = np.arange(len(states))
wgen = data['Total Waste Generation (Tonnes Per Day)']
plt.figure(figsize=(14,6))
plt.ylim([0,12000])
plt.xticks(x, states,rotation=70,horizontalalignment='right')
plt.bar(states,wgen)
plt.title(" State wise Waste Generation per day",fontsize='20')
#plt.savefig('Perdaygraph.png')

from pandas import DataFrame
import matplotlib.pyplot as plt
data = pd.read_csv('Statewiseperdaywaste2.csv')
states = data['State'].values
x = np.arange(len(states))
wgen = data['Total Waste Generation (Tonnes Per Day)']
plt.figure(figsize=(14,15))
colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#8c564b","black","#8f9805","mediumvioletred","white","pink","grey","coral","plum","y","palegreen","orchid","slategrey"]
explode = (0.1, 0, 0, 0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)  

plt.pie(wgen, labels=states , explode=explode, colors=colors, shadow=True, startangle=90)

plt.title("Waste Generation per day ",fontsize="20")
plt.show()
#plt.savefig('perdaypie.png')

data = pd.read_csv('StateUTfuture pred.csv')

%matplotlib inline
print(data.States)
plt.figure(figsize=(10,5))
plt.ylim([0,12000])
round(data.totalwast2020).plot(kind='bar') 
plt.tick_params(axis='x', rotation=70)
plt.title('Waste Generation-2020',fontsize=15) 
plt.show()

#plt.savefig('wastepred2020.png')

data = pd.read_csv('StateUTfuture pred.csv')

%matplotlib inline
#print(data.States)
plt.figure(figsize=(10,5))
round(data.totalwast2021).plot(kind='bar') 
plt.tick_params(axis='x', rotation=70)
plt.title('Waste Generation-2021',fontsize=15) 
plt.show()


data = pd.read_csv('StateUTfuture pred.csv')

%matplotlib inline
#print(data.States)
plt.figure(figsize=(10,5))
round(data.totalwast2022).plot(kind='bar')
plt.tick_params(axis='x', rotation=70)
plt.title('Waste Generation-2022',fontsize=15)
plt.show()


data = pd.read_csv('StateUTfuture pred.csv')

%matplotlib inline
#print(data.States)
plt.figure(figsize=(10,5))
round(data.totalwast2023).plot(kind='bar') 
plt.tick_params(axis='x', rotation=70)
plt.title('Waste Generation-2023',fontsize=15) 
plt.show()
